#!/bin/sh

ulimit -n 4096
touch /var/log/xinetd.log
chmod 644 /var/log/xinetd.log

exec xinetd -dontfork