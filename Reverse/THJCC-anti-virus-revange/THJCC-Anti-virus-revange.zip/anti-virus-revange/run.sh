#!/bin/bash
export HOME=/home/meow
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
# exec 2>/dev/null # Commented out so you can see shell errors if they occur
timeout 60 /home/meow/anti-virus
