# Linux Kernel challenge box
> Author: 堇姬 Naup

## description
This is a linux kernel challenge environment project for CTF. It can use to pack your kernel challenge which startup by qemu.
It support some functions, like Proof of Work(PoW)、verify CTFd token.

